PinkCraft is Minetest but in Pink.
PinkCat Created PinkCraft because her favorite color was pink.
I hope you enjoy PinkCraft.
:)
